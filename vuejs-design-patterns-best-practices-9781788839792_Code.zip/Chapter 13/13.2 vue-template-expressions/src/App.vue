<template>
  <app-dog-container></app-dog-container>  
</template>

<script>
import DogContainer from './components/DogContainer'
export default {
  components: {
    'app-dog-container': DogContainer
  }
}
</script>

<style>

</style>
