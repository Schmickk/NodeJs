<template>
  <todo-list></todo-list>
</template>

<script>
import TodoList from './components/TodoList'
import TodoItem from './components/TodoItem'
export default {
  components: {
    TodoItem,
    TodoList
  }
}
</script>

<style>

</style>
