export default {
  count(state) {
    return state.count;
  },
};
