export const INCREMENT = 'countStore/INCREMENT';
export const DECREMENT = 'countStore/DECREMENT';
export const RESET = 'countStore/RESET';
