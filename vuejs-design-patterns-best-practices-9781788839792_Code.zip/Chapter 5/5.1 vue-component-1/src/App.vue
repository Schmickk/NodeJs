<template>
  <div>
    <fancy-button></fancy-button>
    <button>I'm another button!</button>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
