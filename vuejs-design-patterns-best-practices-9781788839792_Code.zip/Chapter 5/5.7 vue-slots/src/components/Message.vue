<template>
  <div>
    <h1>I'm part of the Message component!</h1>
    <slot></slot>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
