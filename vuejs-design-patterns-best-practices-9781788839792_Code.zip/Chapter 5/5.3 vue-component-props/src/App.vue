<template>
  <fancy-button></fancy-button>
</template>

<script>
import FancyButton from './components/FancyButton.vue';

export default {
  components: {
    'fancy-button': FancyButton
  }
}
</script>

<style>

</style>
